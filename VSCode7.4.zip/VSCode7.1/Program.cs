﻿// Задача 1: Задайте двумерный массив символов (тип char [,]). Создать строку из символов этого массива.

 {
        // Задаем двумерный массив символов
        char[,] charArray = {
            {'H', 'e', 'l', 'l', 'o'},
            {'W', 'o', 'r', 'l', 'd'}
        };

        // Создаем строку из символов массива
        string resultString = CreateStringFromCharArray(charArray);

        // Выводим результат
        Console.WriteLine("Исходный массив символов:");
        PrintCharArray(charArray);

        Console.WriteLine("\nСтрока из символов массива:");
        Console.WriteLine(resultString);
    }

    static string CreateStringFromCharArray(char[,] charArray)
    {
        int numRows = charArray.GetLength(0);
        int numCols = charArray.GetLength(1);

        // Используем конструктор StringBuilder для более эффективной работы со строками
        System.Text.StringBuilder stringBuilder = new System.Text.StringBuilder();

        for (int i = 0; i < numRows; i++)
        {
            for (int j = 0; j < numCols; j++)
            {
                stringBuilder.Append(charArray[i, j]);
            }
        }

        return stringBuilder.ToString();
    }

    static void PrintCharArray(char[,] charArray)
    {
        int numRows = charArray.GetLength(0);
        int numCols = charArray.GetLength(1);

        for (int i = 0; i < numRows; i++)
        {
            for (int j = 0; j < numCols; j++)
            {
                Console.Write(charArray[i, j] + " ");
            }
            Console.WriteLine();
        }
    }
