﻿// Задача 2: Задайте строку, содержащую латинские буквы в обоих регистрах. 
//Сформируйте строку, в которой все заглавные буквы заменены на строчные.


    {
        // Задаем строку с латинскими буквами в обоих регистрах
        string originalString = "HeLLo WoRLD";

        // Формируем новую строку, в которой все заглавные буквы заменены на строчные
        string lowerCaseString = ConvertUpperCaseToLowerCase(originalString);

        // Выводим результат
        Console.WriteLine("Исходная строка: " + originalString);
        Console.WriteLine("Строка с заменой заглавных на строчные: " + lowerCaseString);
    }

    static string ConvertUpperCaseToLowerCase(string input)
    {
        // Используем метод ToLower для преобразования заглавных букв в строчные
        return input.ToLower();
    }