﻿// Задача 3: Задайте произвольную строку. Выясните, является ли она палиндромом.


 {
        Console.Write("Введите строку: ");
        string inputString = Console.ReadLine();

        // Проверяем, является ли строка палиндромом
        bool isPalindrome = IsPalindrome(inputString);

        // Выводим результат
        if (isPalindrome)
        {
            Console.WriteLine("Введенная строка является палиндромом.");
        }
        else
        {
            Console.WriteLine("Введенная строка не является палиндромом.");
        }
    }

    static bool IsPalindrome(string str)
    {
        // Преобразуем строку к нижнему регистру для учета регистра символов
        str = str.ToLower();

        // Удаляем все пробелы из строки
        str = str.Replace(" ", "");

        int length = str.Length;

        for (int i = 0; i < length / 2; i++)
        {
            // Сравниваем символы с обоих концов строки
            if (str[i] != str[length - 1 - i])
            {
                return false; // Если хотя бы одна пара символов не совпадает, строка не является палиндромом
            }
        }

        return true; // Если все пары символов совпадают, строка является палиндромом
    
    }